package ru.iteco.fmhandroid.dto

data class LoginData(
    val login: String,
    val password: String
)
